export const Greeter = (name: string) => `Hello ${name}`;
